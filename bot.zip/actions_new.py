from dbhelper import DBHelper
import mechanicalsoup
import requests
import re
import time
from bs4 import BeautifulSoup
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


br = {
    '1': 'Стеценко А.',
    '2':'Колесников А.А.',
    '3':'Стамати В.Г.',
    '4':'Черкес Д.Н.',
    '5':'Андронов С.С.',
    '6':'Учанин',
}

bragady = {
    'Стеценко А.' : '=1',
    'Колесников А.А.' : '=2',
    'Стамати В.Г.' : '=3',
    'Черкес Д.Н.' : '=4',
    'Андронов С.С.' : '=5',
    'Учанин' : '=6',
    'Кузнецов А.И.' : '=7',
    'Калюжный Д.Б.' : '=8',
    'Гамайло С.В.' : '=9',
    'Крецул О.Н.' : '=31',
    'Годорожа' : '=32',
    'Климов А.А.' : '=41',
    'Мельник С.В.' : '=42',
    'Горин' : '=43',
    'Котенко' : '=44',
    'Олейник' : '=45',
    'Семилуцкий' : '=46',
    'Билань' : '=47',
    'Сарженюк' : '=48',
    'Чемересюк' : '=49',
    'Калиниченко' : '=50',
}


class Actions_new(DBHelper):
    def __init__(self, chat_id, dbname="users.sqlite"):
        print("starting __init__Actions_half")
        self.browser = mechanicalsoup.StatefulBrowser(
            soup_config={'features': 'lxml'},
            raise_on_404=True,
            user_agent='Popov\'s test bot, got questions ? Call +380669309166',
        )
        self.db = DBHelper(dbname="users.sqlite")
        self.l = "SERGEY994"
        self.p = "0688385328"
        self.head = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"}
        print(self.browser)
        if self.db.get_brigada(chat_id)  == []:
            self.brigada = "Колесников А.А."
        else:
            self.brigada = br[''.join(self.db.get_brigada(chat_id))]
        print(self.brigada)

    def format_query(self, query):
        query_text = query.split(" ")
        query = ['','','','']
        for i, word in enumerate(query_text):
            if i > 3:
                return "Неправильно составлен запрос"
            query[i] = word
        return query

    def login(self):
        self.browser.open('https://oper.odessa.tv/index.php')
        self.browser.select_form('form[method="POST"]')
        self.browser["login"] = self.l
        self.browser["password"] = self.p
        response = self.browser.submit_selected()
        self.key = re.search(r"[\w]{32}$", response.url).group(0)
        return self.key

    def get_user_id(self, street, house, appartment=None):
        r = requests.get(
            "https://oper.odessa.tv/operators.php?uid=" + str(self.key)
                          + "&sel_streets_col_name="+ str(street) +"&sel_cms_operators_col_house="+
                          str(house) +"&sel_cms_operators_col_apartment="+ str(appartment) +"&rows=10&nav=0&order=id")
        print("https://oper.odessa.tv/operators.php?uid=" + str(self.key)
                          + "&sel_streets_col_name="+ str(street) +"&sel_cms_operators_col_house="+
                          str(house) +"&sel_cms_operators_col_apartment="+ str(appartment) +"&rows=10&nav=0&order=id")
        soup = BeautifulSoup(r.text, 'lxml')
        userid = 0
        userdata = []
        try:
            try:
                rows = soup.find_all("tr", class_="cell")
                for row in rows:
                    for cell in row:
                        userdata.append(cell)
                userid = str(userdata[1].text)
                userid = int(userid)
            except IndexError:
                rows = soup.find_all("tr", bgcolor="#E3FFAB")
                for row in rows:
                    for cell in row:
                        userdata.append(cell)
                userid = str(userdata[1].text)
                userid = int(userid)
        except IndexError:
            userid = 666
        return userid

    def get_user_phone(self, id):
        r = requests.get("https://oper.odessa.tv/operators.php?uid=" + str(self.key) + "&form=" + str(id) + "&id=" + str(id) + "&rows=1")
        soup = BeautifulSoup(r.text, 'lxml')
        phone = soup.find('input', { "name" : "mobile" })
        phone_alt = soup.find('input', {"name": "mobile_alt"})
        return phone['value'], phone_alt['value']

    def get_user_mac(self, id):
        try:
            r = requests.get("https://oper.odessa.tv/hosts.php?uid=" + str(self.key) + "&selhid_hosts_col_user=" + str(id))
            soup = BeautifulSoup(r.text, 'lxml')
            mactag = soup.find('td', text=re.compile("(..):(..):(..):(..):(..):(..)"))
            return mactag.text
        except AttributeError:
            return "Нет мака в базе"

    def get_user_base_data(self, id):
        #Funkciya rabotaet tolko esle v operators.php naiden tolko odin abonent
        #rabotaet tolko s 6 znachnimy
        self.browser.open("https://oper.odessa.tv/operators.php?uid="+ str(self.key) +"&chapter=1")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_id'] = int(id)
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        hz = soup.findAll('tr', { "bgcolor" : "#E3FFAB"})
        soup2 = BeautifulSoup(str(hz), 'lxml')
        data = soup2.findAll('td')
        user_base_data = []
        for x in data:
            cell_data = re.sub('([\xa0]*)', '', x.text)
            user_base_data.append(cell_data)
        return user_base_data

    def get_zayavki_one(self, id):
        zayavka = []
        response = self.browser.open("https://oper.odessa.tv/support.php?uid="
                                     + str(self.key) + "&rows=1&nav=0&order=id%20DESC&chapter=1&id=" + str(id))
        #self.browser.select_form('form[name="pages"]')
        #self.browser['sel_cms_operators_col_brigada'] = "Колесников А.А."
        #response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        #print(soup)
        rows = soup.find_all("tr", class_="cell")
        for row in rows:
            #print(row.text)
        #    cell = [i.text for i in row.find_all('td')]
            zayavka.append(row.text)
        #print(zayavki)
        return zayavka

    def get_zayavki_new(self):
        zayavki = []
        #self.u.message.reply_text('Заявки для бригады {brigada}'.format(brigada=self.brigada))
        self.browser.open("https://oper.odessa.tv/support.php?uid=" + str(self.key) + "&chapter=1&rows=200")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_brigada'] = bragady[self.brigada]
        self.browser['sel_support_col_state'] = 'Новое'
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        trs = soup.find_all("tr", class_="cell")
        for tr in trs:
            #print(tr)
            cell = []
            for i, td in enumerate(tr.find_all('td')):
                #print(type(i))
                #if i == 4 or i == 5 or i == 6 or i == 7 or i == 9 or i == 10:
                #    pass
                    #print(i)
                #else:
                    #cell.append(td.text)
                cell.append(td.text)
            zayavki.append(cell)
        #print(zayavki)
        return zayavki
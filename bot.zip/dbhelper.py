import sqlite3
import datetime

print("Start script")


class DBHelper:
    print("Initializing class DBHelper")

    def __init__(self, dbname="users.sqlite"):
        self.dbname = dbname
        self.conn = sqlite3.connect(dbname)
        print("sucsesfully connected to db")
#db.add_item(user_id, phone, brigada, first_name, last_name)
    def setup(self):
        print("creating table")
        stmt = "CREATE TABLE IF NOT EXISTS items (user_id int , phone text, brigada int, first_name text, last_name text)"
        self.conn.execute(stmt)
        self.conn.commit()

    def setup2(self):
        print("Creating News table")
        stmt = "CREATE TABLE IF NOT EXISTS news (news_text text , add_date timestamp , owner text)"
        self.conn.execute(stmt)
        self.conn.commit()

    def setup3(self):
        print("Creating News table Phones")
        stmt = "CREATE TABLE IF NOT EXISTS phones (name text , number text)"
        self.conn.execute(stmt)
        self.conn.commit()

    def add_phone(self, name, phone):
        stmt = "INSERT INTO phones (name, number) VALUES (?, ?)"
        args = (name, phone)
        self.conn.execute(stmt, args)
        self.conn.commit()

    def get_phones(self):
        return self.conn.cursor().execute('select * from phones').fetchall()

    def add_news(self, news_text, owner):
        stmt = "INSERT INTO news (news_text, add_date, owner) VALUES (?, ?, ?)"
        args = (news_text, datetime.datetime.now(), owner)
        self.conn.execute(stmt, args)
        self.conn.commit()
        #self.conn.cursor().execute('select * from foo')
        print(self.conn.cursor().execute('select * from news').fetchall())

    def get_news(self):
        return self.conn.cursor().execute('select * from news').fetchall()
#        stmt = "CREATE TABLE IF NOT EXISTS items (userid int , phone text, brigada int, first_name text, last_name text)"
#db.add_item(user_id, phone, brigada, first_name, last_name)
    def add_item(self, user_id, phone, brigada, first_name, last_name):
        print("DB Add item")
        stmt = "INSERT INTO items (user_id, phone, brigada, first_name, last_name) VALUES (?, ?, ?, ?, ?)"
        args = (user_id, phone, brigada, first_name, last_name)
        self.conn.execute(stmt, args)
        self.conn.commit()
        print("ADDED TO DB")


    def delete_item(self, item_text, owner):
        stmt = "DELETE FROM items WHERE description = (?) AND owner = (?)"
        args = (owner, owner)
        self.conn.execute(stmt, args)
        self.conn.commit()
#user_id, phone, brigada, first_name, last_name
    def get_items(self, owner):
        print("Get items")
        stmt = "SELECT * FROM items WHERE user_id = (?)"
        args = (owner,)
        return [x[0] for x in self.conn.execute(stmt, args)]

    def get_brigada(self, owner):
        stmt = "SELECT  * FROM items WHERE user_id = (?)"
        args = (owner,)
        return [str(x[2]) for x in self.conn.execute(stmt, args)]
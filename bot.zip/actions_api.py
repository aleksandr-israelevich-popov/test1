from dbhelper import DBHelper
import mechanicalsoup
import requests
import re
from bs4 import BeautifulSoup
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


class user(DBHelper):
    def __init__(self, api_key, phone, dbname="users.sqlite"):
        print("starting __init__Actions_API")
        self.db = DBHelper(dbname="users.sqlite")
        self.key = api_key
        self.phone = phone


    def get_session_id(self):
        print("get_session_id")
        r = requests.get("https://api.odessa.tv/tg/getAuth.php?key={key}&masterphone={phone}"
                         .format(key=self.key, phone=self.phone))
        print(r.json()['Auth'])
        self.sessionID = r.json()['Auth']['sessionId']
        return self.key
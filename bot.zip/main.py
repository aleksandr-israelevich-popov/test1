#!/usr/bin/env python
# -*- coding: utf-8 -*-
from actions import Actions, Actions_half
from actions_new import Actions_new
from user import master
from dbhelper import DBHelper
import telegram
import re
from bs4 import BeautifulSoup
import time
from telegram import ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton
from telegram.ext import (Updater, CommandHandler, MessageHandler, Filters, RegexHandler,
                          ConversationHandler, CallbackQueryHandler, InlineQueryHandler)
import requests

import logging

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

br = {
    '1':'Стеценко А.',
    '2':'Колесников А.А.',
    '3':'Стамати В.Г.',
    '4':'Черкес Д.Н.',
    '5':'Андронов С.С.',
    '6':'Учанин',
}

group_chat_id = -305782676


def reg_check(bot, update):
    db = DBHelper()
    if update.message.chat.id in db.get_items(update.message.chat.id):
        pass
    else:
        print("reg_check FALSE")
        update.message.reply_text("Добро пожаловать в чат-бот компании Сана+")
        bot.send_chat_action(update.message.chat.id, 'typing')
        time.sleep(3)
        update.message.reply_text("Похоже вас еще нет в нашей базе данных, вам надо пройти процесс регистрации")
        bot.send_chat_action(update.message.chat.id, 'typing')
        time.sleep(3)
        location_keyboard = KeyboardButton(text="Зарегестрироваться", request_contact=True)
        custom_keyboard = [[location_keyboard]]
        reply_markup = ReplyKeyboardMarkup(custom_keyboard, one_time_keyboard=True)
        bot.sendMessage(update.message.chat.id, 'Регистрация', reply_markup=reply_markup)


def user_reg(bot, update, user_data):
    print("Starting user_reg")
    print(update.message.contact)
    phone = update.message.contact.phone_number
    first_name = update.message.contact.first_name
    last_name = update.message.contact.last_name
    user_id = update.message.contact.user_id
    phone = phone.replace('+','')
    print(phone)
    response = requests.get('https://api.odessa.tv/tg/getAuth.php?key=j2FCjLu4fp4hzBfP&masterphone={phone}'.format(phone=phone[2:12]))
    response = response.json()
    if response['Auth'] == "No such user":
        update.message.reply_text("К сожалению ваc нет в базе данных компании Сана+,"
                                  "пожалуйста обратитесь к администратору.")
    elif response['Auth']['result'] == "User found":
        print("User id DB")
        brigada = response['Auth']['brigada_id']
        db = DBHelper()
        db.add_item(user_id, phone, brigada, first_name, last_name)
        update.message.reply_text('Вот и все ! Теперь вы зарегестрированны ! Начните работу с ботом с команды \"Заявки\"')


def bot_info(bot, update):
    bot.send_message(chat_id=update.message.chat.id, text="***Для общения с ботом используются следующие команды***\n\n"
                                                  "*Заявки*|*заявки*|*з*|*З* - Команды для вывода заявок\n\n"
                                                  "*Дежурства*|*дежурства*|*д*|*Д* - График дежурств\n\n"
                                                  "*т*|*Т*|*Телефон* - Запрос номера телефона, пример ввода: 'Телефон Якира 125 45'\n\n"
                                                  "*MAC*|*mac*|*m*|*м* - Запрос MAC Адреса, пример ввода: 'mac Якира 125 45'\n\n"
                                                  "*Инфо*|*инфо*|*и*|*И* - Запрос основной информации об аккаунте\n\n",
                     parse_mode=telegram.ParseMode.MARKDOWN)


def rereg(bot, update):
    db = DBHelper()
    if update.message.chat.id in db.get_items(update.message.chat.id):
        db.delete_item(str(update.message.chat.id), str(update.message.chat.id))
        update.message.reply_text("Введите нового бригадира")
        reply_keyboard1 = [['Колесников А.А.', 'Стеценко А.'],
                           ['Done']]
        markup1 = ReplyKeyboardMarkup(reply_keyboard1, one_time_keyboard=True)
        update.message.reply_text('Выберите вашу бригаду', reply_markup=markup1)
        brigada = update.message.text
        id = update.message.chat.id
        db.add_item(id, id, brigada)
    else:
        update.message.reply_text("Введите нового бригадира")
        reply_keyboard1 = [['Колесников А.А.', 'Стеценко А.'],
                           ['Done']]
        markup1 = ReplyKeyboardMarkup(reply_keyboard1, one_time_keyboard=True)
        update.message.reply_text('Выберите вашу бригаду', reply_markup=markup1)
    update.message.reply_text('Current state -->> REG_CHOISE')
    return REG_CHOISE


def zayavki(bot, update, user_data):
    print("zayavki")
    reg_check(bot, update)
    ac = Actions(update)
    ac.login()
    ac_new = Actions_new(update.message.chat.id)
    ac_new.login()
    bot.send_message(chat_id=update.message.chat.id, text='Секундоку, сейчас напечатаю ваши заявки'
                                                 , parse_mode=telegram.ParseMode.MARKDOWN)
    ac.print_new(ac_new.get_zayavki_new())



def add_phone(bot, update):
    db = DBHelper()
    data = update.message.text.split(" ")
    db.add_phone(data[1], data[2])
    for news in db.get_phones():
        update.message.reply_text(str(news))


def get_phone(bot, update):
    print("Starting Get phone")
    db = DBHelper()
    for phone in db.get_phones():
        update.message.reply_text(str(phone))


def get_news(bot, update):
    update.message.reply_text("Если вы попали в этот раздел, знайте - "
                              "сейчас это лишь отладочная информация для разрабочиков,"
                              "в дальнейшем тут будут новости компании")
    db = DBHelper()
    for news in db.get_news():
        update.message.reply_text(str(news))


def error(bot, update, error):
    logger.warning('Update "%s" caused error "%s"', update, error)


def user(bot, update):
    db = DBHelper()
    if update.message.chat.id in db.get_items(update.message.chat.id):
        brigada = db.get_brigada(update.message.chat.id)
        print(brigada)
        update.message.reply_text(
            "Пользователь {user} уже есть в базе с бригадой {brigada}".format(user=update.message.chat.id,
                                                                              brigada=brigada))
    else:
        brigada = re.search(r"[^/user ](.*)", update.message.text).group(0)
        update.message.reply_text("Пользователь {user} добавлен в базу с бригадой {brigada}".format(user=update.message.chat.id,brigada=brigada))




def inlineCallbackResponse(bot, update):
    query = update.callback_query
    msg_text = query.message.text.split("   ")
    ach = Actions_half()
    ach.login()
    id = ach.get_user_id(msg_text[0], str(msg_text[1]), msg_text[2])
    responseText = "Скоро добавим данную функцию"
    if query.data == "MAC":
        mac = ach.get_user_mac(id)
        responseText = msg_text[0] + " " + msg_text[1] + " " + msg_text[2] + "  " + mac + "  " + "https://oper.odessa.tv/hosts.php?uid=" + str(ach.key) + "&selhid_hosts_col_user=" + str(id)
        bot.send_message(chat_id=query.message.chat_id,
                         text=responseText)

    elif query.data == "Phone":
        phone, phone_alt = ach.get_user_phone(id)
        responseText = msg_text[0] + " " + msg_text[1] + " " + msg_text[2] + "  +38"+phone + "  " + phone_alt
        bot.send_message(chat_id=query.message.chat_id,
                         text=responseText,
                         parse_mode=telegram.ParseMode.MARKDOWN)

    elif query.data == "History":
        print(id)
        responseText = "Скоро добавим данную функцию"
        r = requests.get(
            "https://oper.odessa.tv/support.php?uid=" + str(ach.key) + "&selhid_support_col_user=" + str(id))
        soup = BeautifulSoup(r.text, 'lxml')
        rows = soup.find_all("tr", class_="cell")
        for row in rows:
            bot.send_message(chat_id=query.message.chat_id,
                         text=str(row.text))

    elif query.data == "inetOn":
        bot.send_message(chat_id=group_chat_id, text='Включите пожалуйста услугу '
                                                             'Интернет по адресу *{adres1}  {adres2}  {adres3}*'.format(
            adres1=msg_text[0],
            adres2=msg_text[1],
            adres3=msg_text[2],
        ), parse_mode=telegram.ParseMode.MARKDOWN)

    elif query.data == "Connect":
        bot.send_message(chat_id=group_chat_id, text='Соедените пожалуйста *{first_name} {last_name}* '
                                                             'с абонентом *{adres1}  {adres2}  {adres3}*'.format(
            adres1=msg_text[0],
            adres2=msg_text[1],
            adres3=msg_text[2],
            first_name=query['message']['chat']['first_name'],
            last_name=query['message']['chat']['last_name']
        ), parse_mode=telegram.ParseMode.MARKDOWN)

    elif query.data == "Done":
        bot.send_message(chat_id=group_chat_id, text='Отметьте пожалуйста заявку '
                                                             '*{adres1}  {adres2}  {adres3}*'
                                                             '`{zayavka}`'
                                                             '\n'
                                                             'как выполненную'.format(
            adres1=msg_text[0],
            adres2=msg_text[1],
            adres3=msg_text[2],
            zayavka=msg_text[3]
        ), parse_mode=telegram.ParseMode.MARKDOWN)

    elif query.data == "Tech":
        print(id)
        ach = Actions_half()
        ach.login()
        data = ach.get_user_base_data(id)
        print(str(data))
        bot.send_message(chat_id=query.message.chat_id, text=str(data), parse_mode=telegram.ParseMode.MARKDOWN)

    elif query.data == "detailed":
        done_button = telegram.InlineKeyboardButton(text="Выполнено", callback_data='Done')
        mac_button = telegram.InlineKeyboardButton(text="MAC", callback_data='MAC')
        phone_button = telegram.InlineKeyboardButton(text="Phone", callback_data='Phone')
        history_button = telegram.InlineKeyboardButton(text="History", callback_data='History')
        call_me_button = telegram.InlineKeyboardButton(text="Соеденить", callback_data='Connect')
        ping_button = telegram.InlineKeyboardButton(text="Ping", callback_data='Ping')
        techinfo_button = telegram.InlineKeyboardButton(text="Техинфо", callback_data='Tech')
        TV_ON_button = telegram.InlineKeyboardButton(text="Включить услугу Интернет", callback_data='inetOn')

        test_keybord = telegram.InlineKeyboardMarkup([[done_button],[call_me_button, techinfo_button],
                                                      [ping_button, TV_ON_button],
                                                      [mac_button, phone_button,history_button]])
        bot.send_message(chat_id=query.message.chat_id,
            text = '*{adres1}  {adres2}  {adres3}*    \n{zayavka}'.format(
                adres1 = msg_text[0],
                adres2=msg_text[1],
                adres3=msg_text[2],
                zayavka=msg_text[5]
            ),
            reply_markup = test_keybord,
                         parse_mode=telegram.ParseMode.MARKDOWN)


def dejurstva(bot, update):
    bot.send_photo(chat_id=update.message.chat.id, photo=open('test.jpg', 'rb'))


def get_user_base_data(bot, update):
    ac = Actions(update)
    ac.login()
    ach = Actions_half()
    ach.login()
    adres = []
    adres = ach.format_query(update.message.text)
    print(adres)
    id = ac.get_user_id(adres[1], adres[2], adres[3])
    print(id)
    data = ac.get_user_base_data(id)
    print(str(data))
    update.message.reply_text(str(data))


def get_adress_phone(bot, update, user_data):
    ac = Actions(update)
    ac.login()
    ach = Actions_half()
    ach.login()
    adres = []
    for word in update.message.text.split(" "):
        adres.append(word)
    print(adres)
    if len(adres) == 4:
        id = ach.get_user_id(adres[1], adres[2], adres[3])
        phone = ach.get_user_phone(id)
        for number in phone:
            if number:
                update.message.reply_text("+38" + number)
    if len(adres) == 3:
        id = ach.get_user_id(adres[1], adres[2], '')
        print(id)
        phone = ach.get_user_phone(id)
        for number in phone:
            if number:
                update.message.reply_text("+38" + number)
    else:
        update.message.reply_text("Неправельно введен запрос")


def get_mac_by_adres(bot, update):
    ach = Actions_half()
    ach.login()
    adres = ach.format_query(update.message.text)
    print(adres)
    id = ach.get_user_id(adres[1], adres[2], adres[3])
    print(id)
    if id == 0:
        update.message.reply_text("Нет такого пользователя")
        return
    mac = ach.get_user_mac(id)
    update.message.reply_text("{adres} {house} {appartment}".format(adres=adres[1],house=adres[2], appartment=adres[3]))
    update.message.reply_text(mac)


def test(bot, update):
    print("Hello")
    ach = Actions_half()
    print(type(ach.format_query(update.message.text)))


def main():
    updater = Updater("600425329:AAFjC9At6cYZJl4VPNNR4znqUDF3jwkwi8c")
    #updater = Updater("697323383:AAEMCSfMOgCYBwM3h6xoSq3qQ2CowvN6VSs")
    db = DBHelper()

    #db.setup()
    #db.setup2()
    #db.setup3()
    #db.add_item("138690087", "+380675568933", 2, "A. Kryvenok", "kryvenok")
    #db.add_item("186124021", "+380674894097", 2, "Andrew", "Gaidulyan")
    dp = updater.dispatcher

    dp.add_handler(RegexHandler('^(Заявки|заявки|з|З)$', zayavki, pass_user_data=True))
    dp.add_handler(RegexHandler('^(Дежурства|дежурства|д|Д)$', dejurstva))
    dp.add_handler(RegexHandler('^(т|Т|Телефон|телефон|T|t)(.*)$', get_adress_phone, pass_user_data=True))
    dp.add_handler(RegexHandler('^(MAC|mac|m|м|M|М|мак|МАК|Мак)(.*)$', get_mac_by_adres))
    dp.add_handler(RegexHandler('^(инфо|и|И|Инфо|Info|I|i)(.*)$', get_user_base_data))
    dp.add_handler(RegexHandler('^(помощ|Помощ)(.*)$', bot_info))
    dp.add_handler(CommandHandler("user", user))
    #dp.add_handler(CommandHandler("add_news", add_news))
    dp.add_handler(CommandHandler("get_news", get_news))
    dp.add_handler(CommandHandler("h", bot_info))
    dp.add_handler(CommandHandler("t", test))
    dp.add_handler(CommandHandler("b", get_user_base_data))
    dp.add_handler(CommandHandler("ap", add_phone))
    dp.add_handler(CallbackQueryHandler(inlineCallbackResponse))
    dp.add_handler(MessageHandler(Filters.contact, user_reg, pass_user_data=True))
    # log all errors
    dp.add_error_handler(error)

    # Start the Bot
    updater.start_polling()

    # Run the bot until you press Ctrl-C or the process receives SIGINT,
    # SIGTERM or SIGABRT. This should be used most of the time, since
    # start_polling() is non-blocking and will stop the bot gracefully.
    updater.idle()


if __name__ == '__main__':
    main()
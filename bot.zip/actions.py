from dbhelper import DBHelper
import mechanicalsoup
import requests
import re
import time
from bs4 import BeautifulSoup
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


br = {
    '1': 'Стеценко А.',
    '2':'Колесников А.А.',
    '3':'Стамати В.Г.',
    '4':'Черкес Д.Н.',
    '5':'Андронов С.С.',
    '6':'Учанин',
}

bragady = {
    'Стеценко А.' : '=1',
    'Колесников А.А.' : '=2',
    'Стамати В.Г.' : '=3',
    'Черкес Д.Н.' : '=4',
    'Андронов С.С.' : '=5',
    'Учанин' : '=6',
    'Кузнецов А.И.' : '=7',
    'Калюжный Д.Б.' : '=8',
    'Гамайло С.В.' : '=9',
    'Крецул О.Н.' : '=31',
    'Годорожа' : '=32',
    'Климов А.А.' : '=41',
    'Мельник С.В.' : '=42',
    'Горин' : '=43',
    'Котенко' : '=44',
    'Олейник' : '=45',
    'Семилуцкий' : '=46',
    'Билань' : '=47',
    'Сарженюк' : '=48',
    'Чемересюк' : '=49',
    'Калиниченко' : '=50',
}


class Actions_half(DBHelper):
    def __init__(self, dbname="users.sqlite"):
        print("starting __init__Actions_half")
        self.browser = mechanicalsoup.StatefulBrowser(
            soup_config={'features': 'lxml'},
            raise_on_404=True,
            user_agent='Popov\'s test bot, got questions ? Call +380669309166',
        )
        self.db = DBHelper(dbname="users.sqlite")
        self.l = "SERGEY994"
        self.p = "0688385328"
        self.head = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"}
        print(self.browser)

    def format_query(self, query):
        query_text = query.split(" ")
        query = ['','','','']
        for i, word in enumerate(query_text):
            if i > 3:
                return "Неправильно составлен запрос"
            query[i] = word
        return query

    def login(self):
        self.browser.open('https://oper.odessa.tv/index.php')
        self.browser.select_form('form[method="POST"]')
        self.browser["login"] = self.l
        self.browser["password"] = self.p
        response = self.browser.submit_selected()
        self.key = re.search(r"[\w]{32}$", response.url).group(0)
        return self.key

    def get_user_id(self, street, house, appartment=None):
        r = requests.get(
            "https://oper.odessa.tv/operators.php?uid=" + str(self.key)
                          + "&sel_streets_col_name="+ str(street) +"&sel_cms_operators_col_house="+
                          str(house) +"&sel_cms_operators_col_apartment="+ str(appartment) +"&rows=10&nav=0&order=id")
        print("https://oper.odessa.tv/operators.php?uid=" + str(self.key)
                          + "&sel_streets_col_name="+ str(street) +"&sel_cms_operators_col_house="+
                          str(house) +"&sel_cms_operators_col_apartment="+ str(appartment) +"&rows=10&nav=0&order=id")
        soup = BeautifulSoup(r.text, 'lxml')
        userid = 0
        userdata = []
        try:
            try:
                rows = soup.find_all("tr", class_="cell")
                for row in rows:
                    for cell in row:
                        userdata.append(cell)
                userid = str(userdata[1].text)
                userid = int(userid)
            except IndexError:
                rows = soup.find_all("tr", bgcolor="#E3FFAB")
                for row in rows:
                    for cell in row:
                        userdata.append(cell)
                userid = str(userdata[1].text)
                userid = int(userid)
        except IndexError:
            userid = 666
        return userid

    def get_user_phone(self, id):
        r = requests.get("https://oper.odessa.tv/operators.php?uid=" + str(self.key) + "&form=" + str(id) + "&id=" + str(id) + "&rows=1")
        soup = BeautifulSoup(r.text, 'lxml')
        phone = soup.find('input', { "name" : "mobile" })
        phone_alt = soup.find('input', {"name": "mobile_alt"})
        return phone['value'], phone_alt['value']

    def get_user_mac(self, id):
        try:
            r = requests.get("https://oper.odessa.tv/hosts.php?uid=" + str(self.key) + "&selhid_hosts_col_user=" + str(id))
            soup = BeautifulSoup(r.text, 'lxml')
            mactag = soup.find('td', text=re.compile("(..):(..):(..):(..):(..):(..)"))
            return mactag.text
        except AttributeError:
            return "Нет мака в базе"

    def get_user_base_data(self, id):
        #Funkciya rabotaet tolko esle v operators.php naiden tolko odin abonent
        #rabotaet tolko s 6 znachnimy
        self.browser.open("https://oper.odessa.tv/operators.php?uid="+ str(self.key) +"&chapter=1")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_id'] = int(id)
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        hz = soup.findAll('tr', { "bgcolor" : "#E3FFAB"})
        soup2 = BeautifulSoup(str(hz), 'lxml')
        data = soup2.findAll('td')
        user_base_data = []
        for x in data:
            cell_data = re.sub('([\xa0]*)', '', x.text)
            user_base_data.append(cell_data)
        return user_base_data

    def get_zayavki_one(self, id):
        zayavka = []
        response = self.browser.open("https://oper.odessa.tv/support.php?uid="
                                     + str(self.key) + "&rows=1&nav=0&order=id%20DESC&chapter=1&id=" + str(id))
        soup = BeautifulSoup(response.text, 'lxml')
        rows = soup.find_all("tr", class_="cell")
        for row in rows:
            zayavka.append(row.text)
        return zayavka

class Actions(DBHelper):
    def __init__(self, upd, dbname="users.sqlite", brigada="Колесников А.А."):
        print("starting __init__")
        self.browser = mechanicalsoup.StatefulBrowser(
            soup_config={'features': 'lxml'},
            raise_on_404=True,
            user_agent='Popov\'s test bot, got questions ? Call +380669309166',
        )
        self.db = DBHelper(dbname="users.sqlite")
        self.u = upd
        self.l = "SERGEY994"
        self.p = "0688385328"
        self.head = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"}
        print(self.db.get_brigada(upd.message.chat.id))
        print(type(self.db.get_brigada(upd.message.chat.id)))
        if self.db.get_brigada(upd.message.chat.id)  == []:
            self.brigada = "Колесников А.А."
        else:
            self.brigada = br[''.join(self.db.get_brigada(upd.message.chat.id))]
        print(self.brigada)

    def login(self):
        print("Starting login")
        self.browser.open('https://oper.odessa.tv/index.php')
        self.browser.select_form('form[method="POST"]')
        self.browser["login"] = self.l
        self.browser["password"] = self.p
        response = self.browser.submit_selected()
        self.key = re.search(r"[\w]{32}$", response.url).group(0)

#get zayavki function - returns zayavki as array
    def get_zayavki_new(self):
        zayavki = []
        self.u.message.reply_text('Заявки для бригады {brigada}'.format(brigada=self.brigada))
        self.browser.open("https://oper.odessa.tv/support.php?uid=" + str(self.key) + "&chapter=1&rows=200")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_brigada'] = bragady[self.brigada]
        self.browser['sel_support_col_state'] = 'Новое'
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        trs = soup.find_all("tr", class_="cell")
        for tr in trs:
            cell = []
            for i, td in enumerate(tr.find_all('td')):
                cell.append(td.text)
            zayavki.append(cell)
        return zayavki

    def get_zayavki_one(self):
        print('get_zayavki_one')
        zayavka = []
        self.browser.open("https://oper.odessa.tv/support.php?uid=" + str(self.key) + "&chapter=1")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_brigada'] = "Колесников А.А."
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        rows = soup.find_all("tr", class_="cell")
        for row in rows:
            cell = [i.text for i in row.find_all('td')]
            zayavka.append(cell)
        return zayavka


    def get_user_id(self, street, house, appartment):
        r = requests.get(
            "https://oper.odessa.tv/operators.php?uid=" + str(self.key)
                          + "&sel_streets_col_name="+ str(street) +"&sel_cms_operators_col_house="+
                          str(house) +"&sel_cms_operators_col_apartment="+ str(appartment) +"&rows=10&nav=0&order=id")
        soup = BeautifulSoup(r.text, 'lxml')
        userdata = []
        rows = soup.find_all("tr", bgcolor="#E3FFAB")
        for row in rows:
            for cell in row:
                userdata.append(cell)
        userid = str(userdata[1].text)
        userid = int(userid)
        return userid

    def get_user_mac(self, id):
        r = requests.get("https://oper.odessa.tv/hosts.php?uid=" + str(self.key) + "&selhid_hosts_col_user=" + str(id))
        soup = BeautifulSoup(r.text, 'lxml')
        mactag = soup.find('td', text=re.compile("(..):(..):(..):(..):(..):(..)"))
        return mactag.text

    def get_user_phone(self, id):
        r = requests.get("https://oper.odessa.tv/operators.php?uid=" + str(self.key) + "&form=" + str(id) + "&id=" + str(id) + "&rows=1")
        soup = BeautifulSoup(r.text, 'lxml')
        phone = soup.find('input', { "name" : "mobile" })
        phone_alt = soup.find('input', {"name": "mobile_alt"})

    def get_user_base_data(self, id):
        print("Starting get user base data")
        #Funkciya rabotaet tolko esle v operators.php naiden tolko odin abonent
        #rabotaet tolko s 6 znachnimy
        self.browser.open("https://oper.odessa.tv/operators.php?uid="+ str(self.key) +"&chapter=1")
        self.browser.select_form('form[name="pages"]')
        self.browser['sel_cms_operators_col_id'] = int(id)
        response = self.browser.submit_selected()
        soup = BeautifulSoup(response.text, 'lxml')
        hz = soup.findAll('tr', { "bgcolor" : "#E3FFAB"})
        soup2 = BeautifulSoup(str(hz), 'lxml')
        data = soup2.findAll('td')
        user_base_data = []
        for x in data:
            cell_data = re.sub('([\xa0]*)', '', x.text)
            user_base_data.append(cell_data)
        return user_base_data

    def print_one_zayavka(self, zayavka):
        keyboard = [[InlineKeyboardButton("Выполнено", callback_data='Done')],
                    [InlineKeyboardButton("MAC", callback_data='MAC'),
                     InlineKeyboardButton("Phone", callback_data='Phone'),
                     InlineKeyboardButton("История", callback_data='History')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        cell_data = re.sub('([n]*)', '', zayavka.__str__())
        cell_data = re.sub('(xa0)*', '', cell_data)
        cell_data = re.sub(r'\\', '', cell_data)
        self.u.message.reply_text(cell_data, reply_markup=reply_markup)

    def print_new(self, zayavki):
        keyboard = [[InlineKeyboardButton("Подробности", callback_data='detailed')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        if len(zayavki) == 0:
            self.u.message.reply_text("Заявок для блигады {brigada} нет".format(brigada=self.brigada))
        else:
            print("Количество заявок "+str(len(zayavki)))
            self.u.message.reply_text("Количество заявок {kolvo}".format(kolvo=len(zayavki)))
            time.sleep(5)
            for zayavka in zayavki:
                print(zayavka)
                cell_data = re.sub('([n]*)', '', zayavka.__str__())
                cell_data = re.sub('(xa0)*', '', cell_data)
                cell_data = re.sub(r'\\', '', cell_data)
                zayavka = cell_data.split("', '")
                for i, z in enumerate(zayavka):
                    print(str(i) + "  " + str(z))
                self.u.message.reply_text('{adres1}    {adres2}    {adres3}    \n'
                                            'Бригада: {brigada} \n'
                                            'Статус: {status}\n'
                                          'Тип заявки: {type}\n'
                                          'ID: {id}   Время подачи заявки: {time_start}   \n{zayavka}                                                           '.format(
                                 id=zayavka[0][2:len(zayavka[0])],
                                brigada=zayavka[7],
                                status=zayavka[10][0:len(zayavka[10])-2],
                                 time_start=zayavka[4],
                                 adres1=zayavka[1],
                                 adres2=zayavka[2],
                                 adres3=zayavka[3],
                                    type=zayavka[9],
                                 zayavka=zayavka[8].replace('r', '\n')
                             ), reply_markup=reply_markup)
